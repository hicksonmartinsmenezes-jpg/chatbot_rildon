const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");

const {
  createBroadcast,
  listBroadcasts,
  getBroadcastRecipients,
  startBroadcast,
  cancelBroadcast,
  deleteBroadcast,
  retryFailedRecipients,
  getBroadcastAudience,
  getBroadcastStats
} = require("../services/broadcast.service");

const router = express.Router();

router.get("/broadcasts", async (req, res) => {
  try {
    const page  = Math.max(1, parseInt(req.query.page  || "1"));
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit || "20")));
    const broadcasts = await listBroadcasts({ page, limit });
    res.json(broadcasts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


const uploadDir = path.join(__dirname, "../uploads/campaigns");

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => {
    const ext      = path.extname(file.originalname);
    const baseName = path.basename(file.originalname, ext)
      .replace(/[^a-zA-Z0-9_\-. ]/g, "")   // remove caracteres perigosos
      .trim()
      .replace(/\s+/g, "_")
      .slice(0, 80) || "arquivo";
    cb(null, `${baseName}-${Date.now()}${ext}`);
  }
});

const ALLOWED_MEDIA = {
  image: new Set([".jpg", ".jpeg", ".png", ".gif", ".webp"]),
  pdf:   new Set([".pdf"]),
  audio: new Set([".mp3", ".ogg", ".m4a", ".wav", ".aac", ".opus"]),
};

function detectMediaType(file) {
  const ext = path.extname(file.originalname).toLowerCase();
  if (ALLOWED_MEDIA.image.has(ext) || file.mimetype.startsWith("image/")) return "image";
  if (ALLOWED_MEDIA.pdf.has(ext)   || file.mimetype === "application/pdf")  return "pdf";
  if (ALLOWED_MEDIA.audio.has(ext) || file.mimetype.startsWith("audio/"))   return "audio";
  return null;
}

const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB — PDFs e áudios podem ser grandes
  fileFilter: (req, file, cb) => {
    const type = detectMediaType(file);
    if (!type) return cb(new Error("Tipo de arquivo não permitido. Use imagem, PDF ou áudio."));
    cb(null, true);
  }
});


router.post("/broadcasts", async (req, res) => {
  try {
    const { title, message, recipients, imageUrl, mediaType } = req.body;

    const broadcast = await createBroadcast({
      title,
      message,
      recipients,
      imageUrl,
      mediaType: mediaType || (imageUrl ? "image" : null),
      createdBy: req.user?.nome || req.user?.usuario || null
    });

    res.status(201).json(broadcast);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});


router.post("/broadcasts/upload", (req, res) => {
  upload.single("media")(req, res, async (err) => {
    if (err) {
      if (req.file?.path) fs.unlink(req.file.path, () => {});
      const msg = err.code === "LIMIT_FILE_SIZE"
        ? "Arquivo muito grande. Máximo permitido: 100 MB."
        : err.message || "Erro ao processar arquivo.";
      return res.status(400).json({ error: msg });
    }

    try {
      if (!req.file) {
        return res.status(400).json({ error: "Nenhum arquivo enviado." });
      }

      const mediaType = detectMediaType(req.file);
      if (!mediaType) {
        fs.unlink(req.file.path, () => {});
        return res.status(400).json({ error: "Tipo de arquivo não permitido." });
      }

      res.json({ url: `/uploads/campaigns/${req.file.filename}`, mediaType });
    } catch (e) {
      if (req.file?.path) fs.unlink(req.file.path, () => {});
      res.status(500).json({ error: e.message });
    }
  });
});

router.get("/broadcasts/audience/:type", async (req, res) => {
  try {
    const { tag, atendenteId } = req.query;
    const audience = await getBroadcastAudience(req.params.type, { tag, atendenteId });
    res.json(audience);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});


router.get("/broadcasts/stats", async (req, res) => {
  try {
    const stats = await getBroadcastStats();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


router.get("/broadcasts/:id/recipients", async (req, res) => {
  try {
    const recipients = await getBroadcastRecipients(req.params.id);
    res.json(recipients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/broadcasts/:id/start", async (req, res) => {
  try {
    const result = await startBroadcast(req.params.id);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/broadcasts/:id/cancel", async (req, res) => {
  try {
    const result = await cancelBroadcast(req.params.id);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/broadcasts/:id/retry", async (req, res) => {
  try {
    const result = await retryFailedRecipients(req.params.id);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.delete("/broadcasts/:id", async (req, res) => {
  try {
    const result = await deleteBroadcast(req.params.id);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;