const logger = require("../utils/logger");
const pool = require("../database/postgres");
const { getBotConfig } = require("./botConfig.service");

const sessions = {};
const timers = {};

const TTL_HORAS = parseInt(process.env.SESSION_TTL_HORAS || "24");

let _sendMessage = null;
let cleanupStarted = false;

// MELHORIA: timeouts lidos dinamicamente do botConfig em vez de fixos no módulo.
// Assim, alterações feitas pelo admin no painel têm efeito nos próximos timers
// sem precisar reiniciar o servidor.
async function getTimeouts() {
  try {
    const cfg = await getBotConfig();
    return {
      avisoMs:   (cfg.timeoutAviso        || parseInt(process.env.AVISO_MINUTOS   || "3")) * 60_000,
      timeoutMs: (cfg.timeoutEncerramento || parseInt(process.env.TIMEOUT_MINUTOS || "5")) * 60_000
    };
  } catch {
    return {
      avisoMs:   parseInt(process.env.AVISO_MINUTOS   || "3") * 60_000,
      timeoutMs: parseInt(process.env.TIMEOUT_MINUTOS || "5") * 60_000
    };
  }
}

async function setSendMessage(fn) {
  _sendMessage = fn;
  const { avisoMs, timeoutMs } = await getTimeouts();
  logger.info(
    `⏱️ Timeout de inatividade ativo (aviso: ${avisoMs / 60000}min | encerramento: ${timeoutMs / 60000}min)`
  );

  await _carregarSessoes();
  _agendarLimpezaTTL();
}

async function _carregarSessoes() {
  try {
    const res = await pool.query(
      `
      SELECT user_id, data
      FROM sessions
      WHERE updated_at > NOW() - ($1 * INTERVAL '1 hour')
      `,
      [TTL_HORAS]
    );

    for (const row of res.rows) {
      sessions[row.user_id] = row.data;
    }

    logger.info(`${res.rowCount} sessão(ões) restauradas do banco`);
  } catch (err) {
    logger.warn(`Não foi possível restaurar sessões: ${err.message}`);
  }
}

function _agendarLimpezaTTL() {
  if (cleanupStarted) return;
  cleanupStarted = true;

  setInterval(async () => {
    try {
      const res = await pool.query(
        `
        DELETE FROM sessions
        WHERE updated_at < NOW() - ($1 * INTERVAL '1 hour')
        `,
        [TTL_HORAS]
      );

      if (res.rowCount > 0) {
        logger.info(`[Sessions] ${res.rowCount} sessão(ões) expirada(s) removida(s)`);
      }
    } catch (err) {
      logger.warn(`[Sessions] Erro na limpeza de TTL: ${err.message}`);
    }
  }, 60 * 60 * 1000);
}

function getSession(userId) {
  return sessions[userId] || { sector: "main" };
}

async function updateSession(userId, data) {
  sessions[userId] = {
    ...getSession(userId),
    ...data
  };

  await _persistirSessao(userId);
  resetTimer(userId);
}

async function clearSession(userId) {
  cancelTimer(userId);
  delete sessions[userId];
  await _removerSessao(userId);
}

async function _persistirSessao(userId) {
  try {
    await pool.query(
      `INSERT INTO sessions (user_id, data, created_at, updated_at)
       VALUES ($1, $2, NOW(), NOW())
       ON CONFLICT (user_id)
       DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
      [userId, JSON.stringify(sessions[userId])]
    );
  } catch (err) {
    logger.warn(`[Sessions] Erro ao persistir sessão ${userId}: ${err.message}`);
  }
}

async function _removerSessao(userId) {
  try {
    await pool.query("DELETE FROM sessions WHERE user_id = $1", [userId]);
  } catch (err) {
    logger.warn(`[Sessions] Erro ao remover sessão ${userId}: ${err.message}`);
  }
}

function cancelTimer(userId) {
  if (timers[userId]) {
    clearTimeout(timers[userId].aviso);
    clearTimeout(timers[userId].fim);
    delete timers[userId];
  }
}

async function isBotAtivo() {
  const botConfig = await getBotConfig();

  return !(
    botConfig.ativo === false ||
    botConfig.ativo === "false"
  );
}

function resetTimer(userId) {
  cancelTimer(userId);

  // MELHORIA: timeouts carregados dinamicamente do botConfig a cada reset
  getTimeouts().then((timeouts) => {
  const avisoMs = timeouts.avisoMs;
  let timeoutMs = timeouts.timeoutMs;

  if (timeoutMs <= avisoMs) {
    logger.warn(
      "[Session] timeoutEncerramento menor ou igual ao timeoutAviso. Ajustando automaticamente."
    );

    timeoutMs = avisoMs + 60_000;
  }

    if (timeoutMs <= avisoMs) {
  logger.warn(
    "[Session] timeoutEncerramento menor ou igual ao timeoutAviso. Ajustando automaticamente."
  );

  timeoutMs = avisoMs + 60_000;
}

    const aviso = setTimeout(async () => {
      if (!_sendMessage) return;

      try {
        if (!(await isBotAtivo())) {
          logger.warn("Bot desativado. Aviso de inatividade ignorado.");
          return;
        }

        await _sendMessage(
          userId,
          `⏳ Ainda está aí? Não recebi resposta nos últimos ${avisoMs / 60000} minutos.\n\nSe precisar de ajuda, é só digitar *0* para voltar ao menu.\n\nVou encerrar o atendimento em mais ${(timeoutMs - avisoMs) / 60000} minuto(s) caso não haja resposta.`
        );
      } catch (err) {
        logger.error("Erro ao enviar aviso de inatividade:", err.message);
      }
    }, avisoMs);

    const fim = setTimeout(async () => {
      if (!_sendMessage) return;

      try {
        if (!(await isBotAtivo())) {
          logger.warn("Bot desativado. Encerramento por inatividade ignorado.");
          return;
        }

        await _sendMessage(
          userId,
          "👋 Atendimento encerrado por inatividade.\n\nQuando quiser, é só mandar uma mensagem que estaremos aqui! 😊"
        );
      } catch (err) {
        logger.error("Erro ao enviar mensagem de encerramento:", err.message);
      } finally {
        await clearSession(userId);
      }
    }, timeoutMs);

    timers[userId] = { aviso, fim };

  }).catch(err => {
    logger.warn(`[Session] Falha ao carregar timeouts: ${err.message}`);
  });
}

module.exports = {
  getSession,
  updateSession,
  clearSession,
  setSendMessage
};